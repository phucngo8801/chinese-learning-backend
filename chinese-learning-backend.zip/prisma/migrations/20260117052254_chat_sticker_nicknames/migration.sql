-- AlterEnum
ALTER TYPE "ChatMessageType" ADD VALUE 'STICKER';
