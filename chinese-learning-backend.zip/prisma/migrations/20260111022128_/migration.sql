-- AlterTable
ALTER TABLE "ChatMessage" ALTER COLUMN "updatedAt" DROP DEFAULT;
